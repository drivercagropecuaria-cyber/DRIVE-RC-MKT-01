import { Router, Request, Response } from 'express';
import { generateStandardFileName, getUploadUrl, B2_CONFIG } from './backblaze.service';
import { saveMetadata, MediaMetadata } from './database.service';

const router = Router();

router.post('/presigned', async (req: Request, res: Response) => {
  try {
    const { filename, contentType, size, metadata } = req.body;
    if (!filename || !metadata) {
      return res.status(400).json({ error: 'Filename e metadata são obrigatórios' });
    }

    const { fileName, folderPath, fullPath } = generateStandardFileName(filename, {
      area: metadata.area || 'GERAL',
      nucleo: metadata.nucleo,
      tema: metadata.tema || 'GERAL',
      status: metadata.status || 'ENTRADA_BRUTO',
    });

    const uploadData = await getUploadUrl(fullPath);

    res.json({
      success: true,
      data: {
        presignedUrl: uploadData.uploadUrl,
        authorizationToken: uploadData.authorizationToken,
        fileName: fileName,
        filePath: fullPath,
        folderPath: folderPath,
        headers: {
          'Authorization': uploadData.authorizationToken,
          'X-Bz-File-Name': encodeURIComponent(fullPath),
          'Content-Type': contentType || 'application/octet-stream',
          'X-Bz-Content-Sha1': 'do_not_verify',
        }
      }
    });
  } catch (error: any) {
    console.error('Erro ao gerar presigned URL:', error);
    res.status(500).json({ error: 'Erro ao gerar URL de upload', details: error.message });
  }
});

router.post('/complete', async (req: Request, res: Response) => {
  try {
    const { filePath, metadata } = req.body;
    console.log('Upload completado:', filePath);

    const parts = filePath.split('/');
    const fileName = parts[parts.length - 1];
    const nameParts = fileName.split('_');
    
    let ano = '', mes = '', dia = '', uuid = '', extensao = '';
    if (nameParts.length >= 8) {
      ano = nameParts[0];
      mes = nameParts[1];
      dia = nameParts[2];
      uuid = nameParts[7]?.split('.')[0] || '';
      extensao = nameParts[7]?.split('.')[1] || '';
    }

    const id = fileName.replace(/\./g, '_');

    const mediaMetadata: MediaMetadata = {
      id,
      fileName,
      filePath,
      size: metadata.size || 0,
      contentType: metadata.contentType || 'application/octet-stream',
      uploadedAt: new Date().toISOString(),
      url: `https://f005.backblazeb2.com/file/${B2_CONFIG.bucketName}/${filePath}`,
      area: metadata.area || 'GERAL',
      nucleo: metadata.nucleo,
      tema: metadata.tema || 'GERAL',
      status: metadata.status || 'ENTRADA_BRUTO',
      ponto: metadata.ponto,
      tipoProjeto: metadata.tipoProjeto,
      funcaoHistorica: metadata.funcaoHistorica,
      ano, mes, dia, uuid, extensao,
    };

    saveMetadata(mediaMetadata);
    console.log('Metadados salvos:', mediaMetadata.id);

    res.json({
      success: true,
      data: {
        message: 'Upload confirmado e catalogado',
        filePath: filePath,
        url: mediaMetadata.url,
        id: mediaMetadata.id,
      }
    });
  } catch (error: any) {
    console.error('Erro ao confirmar upload:', error);
    res.status(500).json({ error: 'Erro ao confirmar upload', details: error.message });
  }
});

router.get('/test', async (req: Request, res: Response) => {
  try {
    const { authorizeB2 } = await import('./backblaze.service');
    const auth = await authorizeB2();
    res.json({
      success: true,
      message: 'Conexão com Backblaze B2 OK',
      data: { apiUrl: auth.apiUrl }
    });
  } catch (error: any) {
    res.status(500).json({ success: false, error: 'Falha na conexão com B2', details: error.message });
  }
});

export default router;