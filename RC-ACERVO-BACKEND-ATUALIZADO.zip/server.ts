import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

app.use(cors({ origin: process.env.FRONTEND_URL || '*' }));
app.use(express.json({ limit: '10mb' }));

app.get('/api/health', (req: any, res: any) => res.json({ status: 'ok' }));

import uploadRoutes from './upload.routes';
import mediaRoutes from './media.routes';
import folderRoutes from './folder.routes';

app.use('/api/upload', uploadRoutes);
app.use('/api/media', mediaRoutes);
app.use('/api/folders', folderRoutes);

app.listen(PORT, () => console.log(`Servidor RC Acervo rodando na porta ${PORT}`));