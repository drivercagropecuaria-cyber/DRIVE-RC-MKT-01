import { Router, Request, Response } from 'express';
import { listFiles, B2_CONFIG } from './backblaze.service';
import { getAllMetadata, saveMetadata, getMetadataById, filterMetadata, getEstatisticas, MediaMetadata } from './database.service';

const router = Router();

router.get('/', async (req: Request, res: Response) => {
  try {
    console.log('[GET /api/media] Listando mídias...');
    let metadados = getAllMetadata();
    console.log(`[GET /api/media] ${metadados.length} mídias encontradas`);
    
    const mediaItems = metadados.map(m => ({
      id: m.id,
      fileName: m.fileName,
      filePath: m.filePath,
      size: m.size,
      uploadedAt: m.uploadedAt,
      url: m.url,
      thumbnailUrl: m.url,
      area: m.area,
      nucleo: m.nucleo,
      tema: m.tema,
      status: m.status,
      ponto: m.ponto,
      tipoProjeto: m.tipoProjeto,
      funcaoHistorica: m.funcaoHistorica,
      ano: m.ano,
      mes: m.mes,
      dia: m.dia,
      uuid: m.uuid,
      extensao: m.extensao,
      tipo: m.extensao?.match(/^(jpg|jpeg|png|gif|webp|bmp)$/i) ? 'imagem' : 'video',
    }));

    res.json({ success: true, data: mediaItems, total: mediaItems.length });
  } catch (error: any) {
    console.error('Erro ao listar mídias:', error);
    res.status(500).json({ error: 'Erro ao listar mídias', details: error.message });
  }
});

router.get('/stats', async (req: Request, res: Response) => {
  try {
    const stats = getEstatisticas();
    res.json({ success: true, data: stats });
  } catch (error: any) {
    res.status(500).json({ error: 'Erro ao obter estatísticas', details: error.message });
  }
});

router.get('/:id/url', async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const metadata = getMetadataById(id);
    if (!metadata) {
      return res.status(404).json({ error: 'Arquivo não encontrado' });
    }
    res.json({ success: true, data: { url: metadata.url, fileName: metadata.fileName } });
  } catch (error: any) {
    res.status(500).json({ error: 'Erro ao gerar URL', details: error.message });
  }
});

export default router;