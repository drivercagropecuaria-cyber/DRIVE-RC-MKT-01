import fs from 'fs';
import path from 'path';

const DB_FILE = path.join('/tmp', 'rc-acervo-data', 'media-metadata.json');

const ensureDir = () => {
  const dir = path.dirname(DB_FILE);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
};

export interface MediaMetadata {
  id: string;
  fileName: string;
  filePath: string;
  size: number;
  contentType: string;
  uploadedAt: string;
  url: string;
  area: string;
  nucleo?: string;
  tema: string;
  status: string;
  ponto?: string;
  tipoProjeto?: string;
  funcaoHistorica?: string;
  ano: string;
  mes: string;
  dia: string;
  uuid: string;
  extensao: string;
}

export function getAllMetadata(): MediaMetadata[] {
  try {
    ensureDir();
    if (!fs.existsSync(DB_FILE)) {
      return [];
    }
    const data = fs.readFileSync(DB_FILE, 'utf-8');
    return JSON.parse(data);
  } catch (error) {
    console.error('Erro ao ler metadados:', error);
    return [];
  }
}

export function saveMetadata(metadata: MediaMetadata): void {
  try {
    ensureDir();
    const allMetadata = getAllMetadata();
    const existingIndex = allMetadata.findIndex(m => m.filePath === metadata.filePath);
    if (existingIndex >= 0) {
      allMetadata[existingIndex] = metadata;
    } else {
      allMetadata.push(metadata);
    }
    fs.writeFileSync(DB_FILE, JSON.stringify(allMetadata, null, 2));
  } catch (error) {
    console.error('Erro ao salvar metadados:', error);
    throw error;
  }
}

export function getMetadataById(id: string): MediaMetadata | null {
  const allMetadata = getAllMetadata();
  return allMetadata.find(m => m.id === id) || null;
}

export function filterMetadata(filters: any): MediaMetadata[] {
  let allMetadata = getAllMetadata();
  if (filters.area) allMetadata = allMetadata.filter(m => m.area === filters.area);
  if (filters.nucleo) allMetadata = allMetadata.filter(m => m.nucleo === filters.nucleo);
  if (filters.tema) allMetadata = allMetadata.filter(m => m.tema === filters.tema);
  if (filters.status) allMetadata = allMetadata.filter(m => m.status === filters.status);
  return allMetadata;
}

export function getEstatisticas() {
  const allMetadata = getAllMetadata();
  const porStatus: Record<string, number> = {};
  const porArea: Record<string, number> = {};
  const porTema: Record<string, number> = {};
  const porTipo = { imagem: 0, video: 0 };
  
  allMetadata.forEach(m => {
    porStatus[m.status] = (porStatus[m.status] || 0) + 1;
    porArea[m.area] = (porArea[m.area] || 0) + 1;
    porTema[m.tema] = (porTema[m.tema] || 0) + 1;
    if (m.extensao?.match(/^(jpg|jpeg|png|gif|webp|bmp)$/i)) porTipo.imagem++;
    else if (m.extensao?.match(/^(mp4|mov|avi|mkv|webm)$/i)) porTipo.video++;
  });
  
  return { totalItens: allMetadata.length, porStatus, porArea, porTema, porTipo };
}