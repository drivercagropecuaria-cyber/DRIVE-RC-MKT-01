# RC Acervo Backend - Instruções de Atualização

## 📋 Arquivos Atualizados

Este pacote contém todos os arquivos corrigidos para o backend funcionar corretamente no Render:

- ✅ `database.service.ts` (NOVO) - Banco de dados JSON para metadados
- ✅ `media.routes.ts` - Retorna mídias com metadados
- ✅ `upload.routes.ts` - Salva metadados após upload
- ✅ `backblaze.service.ts` - Integração com Backblaze B2
- ✅ `server.ts` - Servidor Express
- ✅ `folder.routes.ts` - Rotas de pastas
- ✅ `package.json` - Dependências atualizadas
- ✅ `tsconfig.json` - Configuração TypeScript

## 🚀 Como Atualizar no GitHub

### Opção 1: Upload via GitHub Web (Mais Fácil)

1. Vá em: https://github.com/drivercagropecuaria-cyber/DRIVE-RC-MKT-01
2. Para cada arquivo:
   - Clique no arquivo existente
   - Clique no ícone de lápis (✏️) para editar
   - Substitua o conteúdo
   - Clique em "Commit changes"

### Opção 2: Upload de Múltiplos Arquivos

1. Vá em: https://github.com/drivercagropecuaria-cyber/DRIVE-RC-MKT-01
2. Clique em "Upload files"
3. Arraste todos os arquivos .ts e .json
4. Clique em "Commit changes"

## ✅ Após Atualizar

1. Vá no Render: https://dashboard.render.com
2. Selecione seu serviço `DRIVE-RC-MKT-01`
3. Clique em **"Manual Deploy"** → **"Deploy latest commit"**
4. Aguarde o deploy terminar (2-3 minutos)

## 🧪 Testar

Após o deploy, teste estas URLs:

- Health: https://drive-rc-mkt-01.onrender.com/api/health
- Listar mídias: https://drive-rc-mkt-01.onrender.com/api/media
- Estatísticas: https://drive-rc-mkt-01.onrender.com/api/media/stats

## 📝 Variáveis de Ambiente (já configuradas)

- `B2_ACCOUNT_ID`
- `B2_APPLICATION_KEY`
- `B2_BUCKET_ID`
- `B2_BUCKET_NAME`
- `FRONTEND_URL`
- `PORT`

---

**Pronto! Agora o sistema deve funcionar corretamente!**